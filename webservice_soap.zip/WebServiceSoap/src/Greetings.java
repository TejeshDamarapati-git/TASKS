
public class Greetings {
 
 public String getMessage(String message)
 {
 return "received message "+ message;
 }
}